#import Deep
from sklearn.metrics import accuracy_score, confusion_matrix,precision_score, recall_score
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import recall_score, classification_report, auc, roc_curve

def printResult(Y_test,Y_test1,title):
    print("Result of ",title," :")
    print("accuracy score: ",accuracy_score(Y_test, Y_test1))
    print("precision socre: "+str(precision_score(Y_test, Y_test1)))
    print("recall score: "+str(recall_score(Y_test, Y_test1)))
    print("Confusion matrix:")
    print(confusion_matrix(Y_test,Y_test1))



def autoencoder_ROC_Result(auto,X_test,y_test):
	predictions = auto.predict(X_test)
	mse = np.mean(np.power(X_test - predictions, 2), axis=1)
	error_df = pd.DataFrame({'reconstruction_error': mse,
								'true_class': y_test})
	false_pos_rate, true_pos_rate, thresholds = roc_curve(error_df.true_class, error_df.reconstruction_error)
	roc_auc = auc(false_pos_rate, true_pos_rate,)

	plt.plot(false_pos_rate, true_pos_rate, linewidth=5, label='AUC = %0.3f'% roc_auc)
	plt.plot([0,1],[0,1], linewidth=5)

	plt.xlim([-0.01, 1])
	plt.ylim([0, 1.01])
	plt.legend(loc='lower right')
	plt.title('Receiver operating characteristic curve (ROC)')
	plt.ylabel('True Positive Rate')
	plt.xlabel('False Positive Rate')
	plt.show()

	X_test_pred = auto.predict(X_test)
	X_test_error = np.mean(np.power(X_test - X_test_pred, 2), axis=1)
	error_df = pd.DataFrame({'Reconstruction_error': X_test_error,
								'True_class': y_test})
	
	threshold = thresholds[np.argmax(true_pos_rate - false_pos_rate)]
	y_pred_test = np.int32(X_test_error > threshold)
	printResult(y_test,y_pred_test,"autoencoder")