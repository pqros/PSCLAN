import pandas as pd
import tensorflow as tf
import load2
import noDeepML
import deepML
import pickle as pk
import analysis
from keras.models import load_model

# Path
path=input('File path (Default: "data/data.pkl"): ')
if path == '':
    path = 'data/data.pkl'

# Read method
readMethod=input("Data file type (0 - Pickle file (default), 1 - CSV file): ")
if readMethod == '':
    readMethod = '0'

if readMethod == '0':
	data_new=load2.readPickle(path)
else:
	data_new=load2.readCSV(path)

dataVersion="new"

trainOrPredict=input("Choose function: \n 0 - Train new models(default), 1 - Predict with existing models ")
if trainOrPredict=="" or trainOrPredict=="0":
	output_path = input('Output path (Default: "model/" ): ')
	if output_path == '':
		output_path = './model/'

	

	typeOfTrain=input("Start which type of learning? 0 - Deep learning, 1 - non deep learning")

	if "1" in typeOfTrain :
		#preprocessing
		data=noDeepML.preprocessData(data_new,dataVersion,True)
		#generate X_train, X_test, Y_train, Y_test 
		Z,X_train, X_test, Y_train, Y_test=noDeepML.generateTrainMatrix(data)
		noDeepML.noDeepTraining(Z,X_train, X_test, Y_train, Y_test,output_path)
	if "0" in typeOfTrain:
		data=noDeepML.preprocessData(data_new,dataVersion,False)
		deepML.deepTraining(data,output_path)

elif trainOrPredict=="1":
	
	modelType=input("Which type? 0 - non deep learning model, 1 - deep learning model\n")
	if(modelType=="0"):
		modelPath=input("model Path:\n")
		df=open(modelPath,"rb")
		model=pk.load(df)
		df.close()
		#process data
		data=noDeepML.preprocessData(data_new,dataVersion,True)
		Z,_,_1,_2,_3,=noDeepML.generateTrainMatrix(data,ratio=0.3,printinfo=True)
		X = Z[:, :-1]
		Y = Z[:, -1]
		Y_test=model.predict(X)
		analysis.printResult(Y,Y_test,"given model")

	elif modelType=="1":
		data=noDeepML.preprocessData(data_new,dataVersion,False)
		
		deepType=input("Autoencoder or neural network? 0 - autoencoder, 1 - neural network\n")
		if deepType=="0":


			modelPath=input("Path of model(default ./model/autoencoder.h5):\n")
			if modelPath=="":
				modelPath="./model/autoencoder.h5"
			autoencoder=load_model(modelPath)
			X,y=deepML.transData_autoencoder(data)
			analysis.autoencoder_ROC_Result(autoencoder,X,y)
		

		elif deepType=="1":
			modelDir=input("Direction of model(default ./model/):\n")
			if modelDir=="":
				modelDir="./model/"
			
			with tf.Session() as sess:
				ckpt_state = tf.train.get_checkpoint_state(modelDir)
				#saver = tf.train.Saver()
				saver = tf.train.import_meta_graph(modelDir+"nn_model_best.ckpt.meta")
				# Restore variables from disk.
				saver.restore(sess, tf.train.latest_checkpoint(modelDir))
				print("Model restored.")
				graph=tf.get_default_graph()
				output = tf.get_collection("output")[0]
				
				X_test,y_test=deepML.transData(data.sample(frac=0.1))
				
				y_test_label = y_test.argmax(axis=1)
				X=graph.get_tensor_by_name("X:0")
				y=graph.get_tensor_by_name("y:0")
				y_test_pred = deepML.classify(sess.run(output, feed_dict={X: X_test, y: y_test}))
				analysis.printResult(y_test_label ,y_test_pred,"neural network")


		else:
			print("input error.")
else:
	print("input error.")