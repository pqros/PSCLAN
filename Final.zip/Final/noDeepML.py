from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC
from sklearn.ensemble import IsolationForest
import numpy as np
import pickle
import load2
import analysis

def changeLabel(x):
    if(x!='BENIGN'):
        return 1
    else:
        return 0


def preprocessData(data_new,Type="old",needChangeLabel=False):
    if(Type=="new"):
    #Delete unnecessary columns
        columnsNecessary=[ 'nb_connexions', 'nb_unique_scrPort', 'D1', 'D2',
               'D3', 'D4', 'D5', 'D6', 'D7', 'D8', 'D9', 'D10', 'D11', 'D12', 'D13',
               'min(sentByte)', 'max(sentByte)', 'mean(sentByte)', 'sum(sentByte)',
               'min(rcvdByte)', 'max(rcvdByte)', 'mean(rcvdByte)', 'sum(rcvdByte)', 'Label'
               ]
        droplist = [i for i in data_new.columns if i not in columnsNecessary]
        data_new=data_new.drop(droplist,axis=1)

    #change labels
    if needChangeLabel:
        data_new['Label']=data_new['Label'].apply(changeLabel)
    return data_new


def generateTrainMatrix(data_new,ratio=0.3,printinfo=True):
    # splitting ratio for test and training dataset
    Z = data_new.values.astype(np.float)
    X = Z[:, :-1]
    Y = Z[:, -1]
    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=ratio)
    if(printinfo):
        print("number of instances:")
        print(Z.shape[0])
        print("number of test:")
        print(len(Y_test))
    return Z,X_train, X_test, Y_train, Y_test

def noDeepTraining(Z,X_train, X_test, Y_train, Y_test,outputPath):
    str=input("Choose classifiers? 0 - Decision Tree, 1 - Random Forest, 2 - Linear Support Vector, 3 - Isolation Forest")

    if("0" in str):
    #DESICION TREE - change parameter max_depth
        print("Decision tree:\n")
        maxDepth=input("Max Depth? (-1 for default value).\n")
        if(maxDepth=="-1"):
            tree = DecisionTreeClassifier().fit(X_train, Y_train)
        else:
            tree = DecisionTreeClassifier(max_depth=int(maxDepth)).fit(X_train, Y_train)
        Y_test1 = tree.predict(X_test)
        Y_train1=tree.predict(X_train)
        #print results
        analysis.printResult(Y_train,Y_train1,"Decision tree_Training set")
        analysis.printResult(Y_test,Y_test1,"Decision tree_Test set")

        #save the model
        save=input("Save as a binary file?[y/n]\n")
        if(save=="y"):
            output=open(outputPath+"DecisionTreeClassifier_data_new","wb")
            pickle.dump(tree,output)
            print("Saved as DecisionTreeClassifier_data_new")





    if("1" in str):
        #Random Forest - change parameter max_depth
        print("Random Forest:")
        maxDepth=input("Max Depth? (-1 for default value).\n")
        nEstimators=input("n estimators? (-1 for default value).\n")
        if(maxDepth!="-1" and nEstimators!="-1"):
            forest = RandomForestClassifier(max_depth=int(maxDepth),n_estimators=int(nEstimators)).fit(X_train, Y_train)
        else:
            if(maxDepth!="-1"):
                forest = RandomForestClassifier(max_depth=int(maxDepth)).fit(X_train, Y_train)
            else:
                if(nEstimators!="-1"): 
                    forest = RandomForestClassifier(n_estimators=int(nEstimators)).fit(X_train, Y_train)
                else:
                    forest = RandomForestClassifier().fit(X_train, Y_train)

        Y_test1 = forest.predict(X_test)
        Y_train1 = forest.predict(X_train)
        #print results
        analysis.printResult(Y_train,Y_train1,"Random Forest_Training set")
        analysis.printResult(Y_test,Y_test1,"Random Forest_Test set")

        #save the model
        save=input("Save as a binary file?[y/n]")
        if(save=="y"):
            output=open(outputPath+"RandomForestClassifier_data_new","wb")
            pickle.dump(forest,output)
            print("Saved as RandomForestClassifier_data_new")


    if("2" in str):
        #SVM 
        #because svm can deal with data of large scale, we choose only a part of the data to train and test.
        print("Linear Support Vector:")
        #choose randomly training and test data
        ndataset=20000
        Z_index=np.random.choice(len(Z[:,0]),ndataset)
        X1=Z[Z_index,:-1]
        Y1=Z[Z_index,-1]
        Y1[Y1.nonzero()]=1
        X1_train, X1_test, Y1_train, Y1_test = train_test_split(X1, Y1, test_size=ratio)

        #print basic information
        print("number of instances:")
        print(len(Y1_train)+len(Y1_test))
        print("number of test:")
        print(len(Y1_test))
        print("Start computing(kernel=linear)...")
        SVM=LinearSVC().fit(X1_train, Y1_train)#par defaut kernel='rbf'
        Y1_test1 = SVM.predict(X1_test)
        Y1_train1 = SVM.predict(X1_train)
        analysis.printResult(Y1_train,Y1_train1,"Linear Support Vector_Training set")
        analysis.printResult(Y1_test,Y1_test1,"Linear Support Vector_Test set")
        #save the model
        save=input("Save as a binary file?[y/n]\n")
        if(save=="y"):
            output=open(outputPath+"SVM_data_new","wb")
            pickle.dump(SVM,output)
            print("Saved as SVM_data_new")


    if("3" in str):
        print("Isolation Forest:")

        #choose randomly training and test data
        ndataset=20000
        Z_index=np.random.choice(len(Z[:,0]),ndataset)
        X1=Z[Z_index,:-1]
        Y1=Z[Z_index,-1]
        Y1[Y1==1]=-1
        Y1[Y1==0]=1
        X1_train, X1_test, Y1_train, Y1_test = train_test_split(X1, Y1, test_size=ratio)


        #print basic information
        print("number of instances:")
        print(len(Y1_train)+len(Y1_test))
        print("number of test:")
        print(len(Y1_test))
        p_contamination=len(Y1[Y1==-1])/len(Y1)
        clf = IsolationForest(n_estimators=200,contamination=p_contamination)
        clf.fit(X1_train)
        Y1_test1= clf.predict(X1_test)
        Y1_train1=clf.predict(X1_train)
        #print results
        analysis.printResult(Y1_train,Y1_train1,"Isolation Forest_Training set")
        analysis.printResult(Y1_test,Y1_test1,"Isolation Forest_Test set")

        #save the model
        save=input("Save as a binary file?[y/n]\n")
        if(save=="y"):
            output=open(outputPath+"IsolationForest_data_new","wb")
            pickle.dump(clf,output)
            print("Saved as IsolationForest_data_new")