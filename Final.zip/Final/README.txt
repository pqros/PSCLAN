This is a LAN data identification training program with user friendly interface. 


We offer 4 not deep learning models and 2 deep learning models for training:
Decision Tree, Random Forest, SVC Linear and Isolation Forest;
Autoencoder, Neural Network

We offer two options to input data files:
Pickle files or CSV files

All the models are saved in ./model/, but for autoencoder, its model is saved in ./output/

Attention : 
1. The csv data (raw data) must contain these columns : 
'Source IP', 'Source Port', 'Destination IP', 'Destination Port', 'Timestamp', 'Total Length of Fwd Packets', 'Total Length of Bwd Packets', 'Label']

It will be saved into one single pickle.

2. The pickle data (processed data) should at least contains these columns :
[ 'nb_connexions', 'nb_unique_scrPort', 'D1', 'D2',
       'D3', 'D4', 'D5', 'D6', 'D7', 'D8', 'D9', 'D10', 'D11', 'D12', 'D13',
       'min(sentByte)', 'max(sentByte)', 'mean(sentByte)', 'sum(sentByte)',
       'min(rcvdByte)', 'max(rcvdByte)', 'mean(rcvdByte)', 'sum(rcvdByte)', 'Label'
       ]
