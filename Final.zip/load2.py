import glob
import numpy as np
import pandas as pd
import pickle as pk
import datetime as dt
import os

#This program is used to load processed data
def readPickle(path):
	Z0=open(path,'rb')
	data=pk.load(Z0)
	return data

def splitdate(s):
	return s.date() # Calculate date

def splittime(s):
	return s.time() # Calculate time

def AMtoPM(time_am): # Convert AM time to PM
    if time_am.hour < 8:
        return time_am.replace(hour=time_am.hour+12)#Note that there's many NaNs in day4's data
    else:
        return time_am

def srcportToName(port,top_dstport_list,top_dstport_dict):
    if port in top_dstport_list:
        return top_dstport_dict[port]
    elif port < 1024:
        return 'D11'
    elif port < 49152:
        return 'D12'
    else:
        return 'D13'


def isBenign(l):
    if ('BENIGN' in l) and (len(l) == 1):
        return 'BENIGN'
    else:
        return 'MALIGN'

	# Minute iteration
def addMinutes(tm, mins):
    fulldate = dt.datetime(100, 1, 1, tm.hour, tm.minute, tm.second)
    fulldate = fulldate + dt.timedelta(minutes=mins)
    return fulldate.time()

def readCSV(path):
	columns=['Source IP', 'Source Port', 'Destination IP', 'Destination Port', 'Timestamp', 'Total Length of Fwd Packets', 'Total Length of Bwd Packets', 'Label']

	os.chdir(path)
	file_chdir = os.getcwd() #current folder

	print(file_chdir)
	#Get all file names
	temp_list=[]

	allFiles = glob.glob(path+"*.csv")

	allofcsv = []
	for file in allFiles:
		print('Reading file ' + file)
		temp_data = pd.read_csv(file, encoding='ISO-8859-1', skipinitialspace=True,usecols=columns,parse_dates=['Timestamp'])
		temp_list.append(temp_data)   
	data = pd.concat(temp_list)
	print("Start processing...")
	data = data.dropna(axis = 0, how = 'any')
    
    #Extract date and time
	print("Processing date and time...")
	data['Date'] = data['Timestamp'].apply(splitdate)
	data['Time'] = data['Timestamp'].apply(splittime)
    
    #Convert AM to PM
	data['Time'] = data['Time'].apply(AMtoPM)

	data.rename(columns={'Destination Port':'dstport'},inplace=True)

	#Mark D1 to D13
	print("Processing destination port ...")
	top_dstport_list = data['dstport'].value_counts().index.tolist()[:10]

	top_dstport_dict = {}
	for i in range(1, 11):
		top_dstport_dict[top_dstport_list[i-1]] = 'D' + str(i)
    
	# Classify destination ports
	data['dstport'] = data['dstport'].apply(srcportToName, args = (top_dstport_list,top_dstport_dict))
	newcols = ['srcip', 'dstip', 'begin_time', 'nb_connexions', 'nb_unique_scrPort', 'D1', 'D2',
       'D3', 'D4', 'D5', 'D6', 'D7', 'D8', 'D9', 'D10', 'D11', 'D12', 'D13',
       'min(sentByte)', 'max(sentByte)', 'mean(sentByte)', 'sum(sentByte)',
       'min(rcvdByte)', 'max(rcvdByte)', 'mean(rcvdByte)', 'sum(rcvdByte)', 'Label'
       ]

	# Set interval parameters
	time_interval = 15
	time_split = 3
	time_slide = time_interval/time_split
	# Construct one-hot IP intervals and sort the array
	data_list=[]
	for date in data['Date'].unique():
		data_list.append(data.loc[data['Date']==date])

	data_all_list = []
	for data_temp in data_list:
		# Create a table to show results
		data_new = pd.DataFrame(columns=newcols)

		dstport_list = []
		for i in range(1, 14):
			dstport_list.append('D'+str(i))
		dstport_onehot = pd.get_dummies(data_temp['dstport'])
		for dstport in dstport_list:
			data_temp[dstport] = dstport_onehot[dstport]

		data_temp = data_temp.sort_values(by='Time')
		data_temp.reset_index(drop=True, inplace=True)

		# [index_list[i], index_list[i + timeSplit]) is the i^{th} interval
		index_list = []
		time_list = []
		min_time = data_temp['Time'].min()
	
		begin_time = min_time
		for i in range(data_temp.shape[0]):
			if data_temp['Time'][i] >= begin_time:
				time_list.append(begin_time)
				index_list.append(i)
				begin_time = addMinutes(begin_time, time_slide)
            
		for i in range(len(time_list)-time_split):
			begin_index = index_list[i]
			end_index = index_list[i+time_split]
			data_temp1 = data_temp.iloc[begin_index:end_index,:]

			# Group by Source IP and Destination IP
			group = data_temp1.groupby(by=['Source IP','Destination IP'])

			
			# Add group information + nb_connections
			dataV = pd.DataFrame({'nb_connexions': group.size()}).reset_index()

			# Count the number of unique source ports (nb_unique_scrPort)
			dataV['nb_unique_scrPort'] = np.array(group['Source Port'].nunique())

			# Count the number of D1 to D13
			group_sum = group.sum()
			for dstport in dstport_list:
				dataV[dstport] = np.array(group_sum[dstport])

			# Summary of sent(forward) bytes
			dataV['min(sentByte)'] = np.array(group['Total Length of Fwd Packets'].min())
			dataV['max(sentByte)'] = np.array(group['Total Length of Fwd Packets'].max())
			dataV['mean(sentByte)'] = np.array(group['Total Length of Fwd Packets'].mean())
			dataV['sum(sentByte)'] = np.array(group['Total Length of Fwd Packets'].sum())

			# Summary of received(backward) bytes
			dataV['min(rcvdByte)'] = np.array(group['Total Length of Bwd Packets'].min())
			dataV['max(rcvdByte)'] = np.array(group['Total Length of Bwd Packets'].max())
			dataV['mean(rcvdByte)'] = np.array(group['Total Length of Bwd Packets'].mean())
			dataV['sum(rcvdByte)'] = np.array(group['Total Length of Bwd Packets'].sum())

			# Add label to dataframe
			dataV['Label'] = np.array(group['Label'].unique().apply(isBenign))

			# Add time information
			dataV['begin_time'] = time_list[0]

			# Rename
			dataV = dataV.rename(columns={'Source IP':'srcip', 'Destination IP':'dstip'})

			# Change Column Order
			dataV = dataV[newcols]

			# Add to the final table
			data_new = data_new.append(dataV)

			# Print related informations
			print('Finished '+str(time_list[i])+' to '+str(time_list[i+time_split]) + '.')
			print('Added ' + str(dataV.shape[0]) + ' new lines; There are ' + str(data_new.shape[0]) + ' lines.')

		#data_new['Date'] = data_temp['Date'][0]
		print(data_new.columns)
		print('Finished file. Writing into ' + ("new_data"+str(date)+".pkl"))
		with open(path + ("new_data_"+str(date)+".pkl"), 'wb') as f:
			pk.dump(data_new, f)
		data_all_list.append(data_new)
	data_all=pd.concat(data_all)
	return data_all

