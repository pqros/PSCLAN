from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC
from sklearn.ensemble import IsolationForest
import numpy as np
import pickle
import load2
import analysis
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve,auc

def changeLabel(x):
    if(x!='BENIGN'):
        return 1
    else:
        return 0


def preprocessData(data_new,Type="old",needChangeLabel=False):
    if(Type=="new"):
    #Delete unnecessary columns
        columnsNecessary=[ 'nb_connexions', 'nb_unique_scrPort', 'D1', 'D2',
               'D3', 'D4', 'D5', 'D6', 'D7', 'D8', 'D9', 'D10', 'D11', 'D12', 'D13',
               'min(sentByte)', 'max(sentByte)', 'mean(sentByte)', 'sum(sentByte)',
               'min(rcvdByte)', 'max(rcvdByte)', 'mean(rcvdByte)', 'sum(rcvdByte)', 'Label'
               ]
        droplist = [i for i in data_new.columns if i not in columnsNecessary]
        data_new=data_new.drop(droplist,axis=1)

    #change labels
    if needChangeLabel:
        data_new['Label']=data_new['Label'].apply(changeLabel)
    return data_new


def generateTrainMatrix(data_new,ratio=0.3,printinfo=True):
    # splitting ratio for test and training dataset
    Z = data_new.values.astype(np.float)
    X = Z[:, :-1]
    Y = Z[:, -1]
    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=ratio)
    if(printinfo):
        print("number of instances:")
        print(Z.shape[0])
        print("number of test:")
        print(len(Y_test))
    return Z,X_train, X_test, Y_train, Y_test

def noDeepTraining(Z,X_train, X_test, Y_train, Y_test,outputPath):
    str=input("Choose classifiers? 0 - Decision Tree, 1 - Random Forest, 2 - Linear Support Vector, 3 - Isolation Forest")

    if("0" in str):
    #DESICION TREE - change parameter max_depth
        print("Decision tree:\n")
        maxDepth=input("Max Depth? (-1 for default value).\n")
        if(maxDepth=="-1"):
            tree = DecisionTreeClassifier().fit(X_train, Y_train)
        else:
            tree = DecisionTreeClassifier(max_depth=int(maxDepth)).fit(X_train, Y_train)
        Y_test1 = tree.predict(X_test)
        Y_train1=tree.predict(X_train)
        #print results
        analysis.printResult(Y_train,Y_train1,"Decision tree_Training set")
        analysis.printResult(Y_test,Y_test1,"Decision tree_Test set")

        #save the model
        save=input("Save as a binary file?[y/n]\n")
        if(save=="y"):
            output=open(outputPath+"DecisionTreeClassifier_data_new","wb")
            pickle.dump(tree,output)
            print("Saved as DecisionTreeClassifier_data_new")





    if("1" in str):
        #Random Forest - change parameter max_depth
        print("Random Forest:")
        maxDepth=input("Max Depth? (-1 for default value).\n")
        nEstimators=input("n estimators? (-1 for default value).\n")
        if(maxDepth!="-1" and nEstimators!="-1"):
            forest = RandomForestClassifier(max_depth=int(maxDepth),n_estimators=int(nEstimators)).fit(X_train, Y_train)
        else:
            if(maxDepth!="-1"):
                forest = RandomForestClassifier(max_depth=int(maxDepth)).fit(X_train, Y_train)
            else:
                if(nEstimators!="-1"): 
                    forest = RandomForestClassifier(n_estimators=int(nEstimators)).fit(X_train, Y_train)
                else:
                    forest = RandomForestClassifier().fit(X_train, Y_train)


        Y_test1 = forest.predict(X_test)
        Y_train1 = forest.predict(X_train)
        #print results
        analysis.printResult(Y_train,Y_train1,"Random Forest_Training set")
        analysis.printResult(Y_test,Y_test1,"Random Forest_Test set")

        #save the model
        save=input("Save as a binary file?[y/n]")
        if(save=="y"):
            output=open(outputPath+"RandomForestClassifier_data_new","wb")
            pickle.dump(forest,output)
            print("Saved as RandomForestClassifier_data_new")


    if("2" in str):
        #SVM 
        #because svm can deal with data of large scale, we choose only a part of the data to train and test.
        print("Linear Support Vector:")
        #choose randomly training and test data
        ndataset=200000
        Z_index=np.random.choice(len(Z[:,0]),ndataset)
        X1=Z[Z_index,:-1]
        Y1=Z[Z_index,-1]
        Y1[Y1.nonzero()]=1
        X1_train, X1_test, Y1_train, Y1_test = train_test_split(X1, Y1, test_size=0.3)

        #print basic information
        print("number of instances:")
        print(len(Y1_train)+len(Y1_test))
        print("number of test:")
        print(len(Y1_test))
        print("Start computing(kernel=linear)...")
        SVM=LinearSVC().fit(X1_train, Y1_train)#par defaut kernel='rbf'
        Y1_test1 = SVM.predict(X1_test)
        Y1_train1 = SVM.predict(X1_train)
        analysis.printResult(Y1_train,Y1_train1,"Linear Support Vector_Training set")
        analysis.printResult(Y1_test,Y1_test1,"Linear Support Vector_Test set")
        #save the model
        save=input("Save as a binary file?[y/n]\n")
        if(save=="y"):
            output=open(outputPath+"SVM_data_new","wb")
            pickle.dump(SVM,output)
            print("Saved as SVM_data_new")


    if("3" in str):
        print("Isolation Forest:")
        ratio=0.3
        #choose randomly training and test data
        #ndataset=400000
        #Z_index=np.random.choice(len(Z[:,0]),ndataset)
        #X1=Z[Z_index,:-1]
        #Y1=Z[Z_index,-1]
        X1=Z[:,:-1]
        Y1=Z[:,-1]
        X1_train, X1_test, Y1_train, Y1_test = train_test_split(X1, Y1, test_size=ratio)


        #print basic information
        print("number of instances:")
        print(len(Y1_train)+len(Y1_test))
        print("number of test:")
        print(len(Y1_test))
        p_contamination=len(Y1[Y1==1])/len(Y1)
        print("ratio of anomalies: ",p_contamination)
        clf = IsolationForest(n_estimators=200,contamination=240*p_contamination)
        clf.fit(X1_train)
        Y1_test1= clf.predict(X1_test)
        Y1_train1=clf.predict(X1_train)
        Y1_test1[Y1_test1==1]=0
        Y1_test1[Y1_test1==-1]=1
        Y1_train1[Y1_train1==1]=0
        Y1_train1[Y1_train1==-1]=1
        #print results
        analysis.printResult(Y1_train,Y1_train1,"Isolation Forest_Training set")
        analysis.printResult(Y1_test,Y1_test1,"Isolation Forest_Test set")
        #y_pred = clf.score_samples(X)
        scoring = - clf.decision_function(X1_test)
		####start plot decision_function_histograms
        fig, ax = plt.subplots(3, sharex=True, sharey=True)
        bins = np.linspace(-0.5, 0.5, 200)
        ax[0].hist(scoring, bins, color='black')
        ax[0].set_title('Decision function')
        ax[1].hist(scoring[Y1_test == 0], bins, color='b', label='normal data')
        ax[1].legend(loc="lower right")
        ax[2].hist(scoring[Y1_test == 1], bins, color='r', label='outliers')
        ax[2].legend(loc="lower right")

		####start plot roc curve
        fig_roc, ax_roc = plt.subplots(1, 1, figsize=(8, 5))
        fpr, tpr, thresholds = roc_curve(Y1_test,scoring)
        auc_score = auc(fpr, tpr)

        ax_roc.plot(fpr, tpr,  linewidth=5,label=("AUC score:%f" % (auc_score)) )
        ax_roc.set_xlim([-0.05, 1.05])
        ax_roc.set_ylim([-0.05, 1.05])
        plt.plot([0,1],[0,1], linewidth=5)
        plt.xlim([-0.01, 1])
        plt.ylim([0, 1.01])
        ax_roc.set_xlabel('False Positive Rate')
        ax_roc.set_ylabel('True Positive Rate')
        ax_roc.set_title('Receiver operating characteristic (ROC) curves')
        ax_roc.legend(loc="lower right")
        fig_roc.tight_layout()
        plt.show()
        #save the model
        save=input("Save as a binary file?[y/n]\n")
        if(save=="y"):
            output=open(outputPath+"IsolationForest_data_new","wb")
            pickle.dump(clf,output)
            print("Saved as IsolationForest_data_new")