# Import packages used for deep learning
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, precision_recall_curve
from sklearn.metrics import recall_score, classification_report, auc, roc_curve
from sklearn.metrics import precision_recall_fscore_support, f1_score, accuracy_score, precision_score,average_precision_score
from keras.models import Model, load_model
from keras.layers import Input, Dense
from keras.callbacks import ModelCheckpoint, TensorBoard
from sklearn.utils import shuffle
import tensorflow as tf
import analysis
#Show prediction results in ont-hot form
def classify_onehot(y_pred):
    nclass = y_pred.shape[1]
    y_max = y_pred.argmax(axis=1) #Find the index of the larger element of each row
    with tf.Session() as sess:
        y_pred_onehot = sess.run(tf.one_hot(y_max, depth=nclass))
    return y_pred_onehot

#Show prediction results in index form
def classify(y_pred):
    nclass = y_pred.shape[1]
    y_max = y_pred.argmax(axis=1) #Find the index of the larger element of each row
    return y_max

def ASSampling(data):

	return

def transData(data):
  #normalization to 0 ~ 1
	X_data = (data.drop(['Label'], axis=1)).astype(np.float32)
	X_data = np.log(X_data - X_data.min() + 1)
	X_data = (X_data - X_data.min())/(X_data.max() - X_data.min())
	X_data = X_data.drop(X_data.columns[X_data.isna().any().tolist()], axis=1)
	X_data = X_data.values
	y_data = 1 - np.float32(data['Label'] == 'BENIGN') #y = 1 represents anomalies
	#Make one-hot labels 
	with tf.Session() as sess:
		y_data = sess.run(tf.one_hot(y_data, depth=2))


	return X_data,y_data


def neuralNetwork(data,output_path,nlayer1 = 512,nlayer2 = 256,nlayer3 = 128,learning_rate = 0.0002,num_steps = 10000):
	
	#split data into training set and test set
	#X_train, X_test, y_train, y_test = train_test_split(X_data, y_data, test_size=0.3)
	nclasses = 2
	X_data,y_data=transData(data)

	#Construct the network
	ninput = X_data.shape[1] # Input dimension
	#nlayer1 = 512 # Neuron number of layer 1
	#nlayer2 = 256 # Neuron number of layer 2
	#nlayer3 = 128 # Neuron number of layer 3

	#learning_rate = 0.00002 # Learning rate
	#num_steps = 10000 # Number of training epochs
	display_step = 1000# Print loss every 1000 epochs
	batch_size = 512
	save_step = 1000 #Save the model every 5000 epochs

	X = tf.placeholder(tf.float32, shape=[None, ninput], name='X')
	y = tf.placeholder(tf.float32, shape=[None, nclasses], name='y')
	W1 = tf.Variable(tf.random_normal([ninput, nlayer1])) #
	W2 = tf.Variable(tf.random_normal([nlayer1, nlayer2]))
	W3 = tf.Variable(tf.random_normal([nlayer2, nlayer3]))
	W4 = tf.Variable(tf.random_normal([nlayer3, nclasses]))
	b1 = tf.Variable(tf.random_normal([nlayer1]))
	b2 = tf.Variable(tf.random_normal([nlayer2]))
	b3 = tf.Variable(tf.random_normal([nlayer3]))
	b4 = tf.Variable(tf.random_normal([nclasses]))

	layer1 = tf.nn.relu(tf.matmul(X, W1) + b1)
	layer2 = tf.nn.relu(tf.matmul(layer1, W2) + b2)
	layer3 = tf.nn.relu(tf.matmul(layer2, W3) + b3)
	output = tf.matmul(layer3, W4) + b4
	tf.add_to_collection("output",output)
	loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(logits=output, labels=y))
	optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(loss)
		#Train the network
	#Remark: mini-batch of 256 is largely instable. Learning rate is optimized over 10^-6 ~ 10^-3
	#Train count (we have the choice to train several times and take the best)
	train_number = 5 #the number of training we do
	accuracy_best = 0
	#y_test_label = y_test.argmax(axis=1) #True label in the test set
	#cntMax = int(X_train.shape[0]/batch_size)

	saver = tf.train.Saver(max_to_keep=1)
	print("start training...")
	for total_train_cnt in range(train_number): #Run 5 times and take the best
		with tf.Session() as sess:
			sess.run(tf.global_variables_initializer())
			cnt = 0

			#each time, we resample the training data
			data11=data.loc[data['Label']=='MALIGN']
			data12=data.sample(data11.shape[0]*8)
			data1=pd.concat([data11,data12])
			X_train, y_train = transData(data1)

			cntMax = int(X_train.shape[0]/batch_size)
			# so no need to shuffle(X_train, y_train)

			x_index = []
			train_loss = []
			test_loss = []
			for i in range(1, num_steps+1):
				cnt = cnt + 1
				if cnt > cntMax:
					X_train, y_train = shuffle(X_train, y_train)
					cnt = 1
				_, l = sess.run([optimizer, loss], 
					feed_dict={y: y_train[(cnt - 1) * batch_size : cnt * batch_size, :], 
							X: X_train[(cnt - 1) * batch_size : cnt * batch_size, :]})
				if i % display_step== 0:
					print('Epoch %i: Minibatch Loss = %f' % (i, l))

					#each time we test, we choose randomly a test set, with some anomalies
					n_test=int(len(y_train)*0.3/0.7)
					data21=data.sample(n_test)
					data22=data.loc[data['Label']=='MALIGN']
					data22=data22.sample(int(data22.shape[0]*np.random.rand()))
					data2=pd.concat([data21,data22])
					#generate test set
					X_test,y_test=transData(data2)

					y_test_label = y_test.argmax(axis=1) #True label in the test set
					
					y_test_pred = classify(sess.run(output, feed_dict={X: X_test, y: y_test}))
					accuracy_test = average_precision_score(y_test_label, y_test_pred)
					print('Current auPR: ' + str(accuracy_test))
					print('Current recall: ' + str(recall_score(y_test_label, y_test_pred)))
					if accuracy_test > accuracy_best:
						accuracy_best = accuracy_test
						saver.save(sess, output_path+'nn_model_best.ckpt')
			print ("Best accuracy: " + str(accuracy_best))
			



	


def transData_autoencoder(data):
	#Attack -> 1, #Non-attack -> 0
	data['Label'] = 1 - (data['Label'] == 'BENIGN')

	#data=data.drop(data['Label']==1,axis=0)
	# Normalize all data with log + (-1 ~ 1)
	# All labels
	y_data = data['Label'].values
	X_data = data.drop(['Label'], axis=1).astype(np.float32)
	X_data = np.log(X_data - X_data.min() + 1)
	X_data = 2 * (X_data - X_data.min())/(X_data.max() - X_data.min()) - 1
	X_data = (X_data.drop(X_data.columns[X_data.isna().any().tolist()], axis=1)).values
	# X_data = np.float32(X_data)
	return X_data,y_data




def deepTraining(data,output_path):
	training_model = input('Training model (0 - Autoencoder, 1 - Neural network): ')

	if training_model == '0':
		
		X_data,y_data=transData_autoencoder(data)
		input_dim = X_data.shape[1]

		#Select all benign data
		# X_data_benign = X_data[y_data == 0]
		X_train, X_test, y_train, y_test = train_test_split(X_data, y_data, test_size=0.3)

		nb_epoch = 30
		batch_size = 512
		dim_layer1 = int(input_dim/2)
		dim_layer2 = int(dim_layer1/2)
		learning_rate = 5e-6

		input_layer = Input(shape=(input_dim, ))

		# Encoder
		encoder = Dense(dim_layer1, activation="tanh",
		#                activity_regularizer=regularizers.l1(10e-5)
					   )(input_layer)
		encoder = Dense(dim_layer2, activation="tanh")(encoder)

		# Decoder
		decoder = Dense(dim_layer1, activation='tanh')(encoder)
		decoder = Dense(input_dim, activation='tanh')(decoder)
		autoencoder = Model(inputs=input_layer, outputs=decoder)

		# Start Training

		autoencoder.compile(metrics=['accuracy'],
						loss='mean_squared_error',
						optimizer='adam')

		cp = ModelCheckpoint(filepath=output_path+"autoencoder.h5",
									   save_best_only=True,
									   verbose=0)

		tb = TensorBoard(log_dir='./logs',
						histogram_freq=0,
						write_graph=True,
						write_images=True)

		history = autoencoder.fit(X_train, X_train,
							epochs=nb_epoch,
							batch_size=batch_size,
							shuffle=True,
							validation_data=(X_test, X_test),
							verbose=1,
							callbacks=[cp, tb]).history
		print('Saved the model as ' + output_path + 'autoencoder.h5!')
		print('Saved the log files in logs')

		# Visualize the ROC curve and print other metrics
		analysis.autoencoder_ROC_Result(autoencoder,X_test,y_test)

	elif training_model == '1':
		neuralNetwork(data,output_path)
	else:   
		print('Input error. Program terminated.')
